		<footer>
			<!-- the php date() function can be used to display the current year in the footer -->
			<p>Gorgeous Cupcakes &copy; <?php echo date('Y'); ?></p>
		</footer> <!-- end footer -->
	</section> <!-- end container started in the header -->
</body> <!-- end body started in the header -->
</html> <!-- end html started in the header -->